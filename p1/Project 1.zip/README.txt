CS5500 - Project 1
Kevin Cardenas, James Turner and Noah Rodgers

1. Build and Run
	In order to build and run our program, please save all our files into one folde. Open your terminal and navigate to where you saved our folder, and run the command `make linkedlist`.
	
2. Pieces of the Assignment
	In total, there are 4 files: Makefile, list_test.c, list.c, and list.h. The Makefile contains a script to compile our C files. The list.h file is a header file containing all of the functions. The list.c file contains the code for the functions outlined in list.h. Finally, list_test.c tests all of the functions writted in list.c. 
	The link_test.c file contains multiple test cases to test each function, as well as various combinations of these functions.

3. Challenges
	The main challenge was dusting off the cobwebs for C programming, how to compile with gcc, and how to create/use a Makefile. 

4. Notes
	Each teammember individually completed the project in order to get some practice before future, more challenging projects. We then finalized our work using Kevin's files and VM. We did not dicuss this project with any other individuals or teams.

